package com.zr.service.sys.impl;

import org.springframework.stereotype.Service;

@Service
public class RoleAuthServiceImpl {
}
