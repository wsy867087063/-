package com.zr.service.sys;

public interface RoleAuthService {
}
