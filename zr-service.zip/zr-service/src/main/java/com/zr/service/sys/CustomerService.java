package com.zr.service.sys;

import com.zr.vo.lease.Customer;

public interface CustomerService {

    Customer login(Customer customer);
}
